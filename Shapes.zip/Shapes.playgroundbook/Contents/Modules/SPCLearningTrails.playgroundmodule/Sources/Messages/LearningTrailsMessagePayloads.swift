//
//  LearningTrailsMessagePayloads.swift
//  
//  Copyright © 2020 Apple Inc. All rights reserved.
//

import Foundation

struct LearningTrailsOriginPayload: Codable {
    var origin: LearningTrailsMessageOrigin
}
